<?php

/**

 *
 * @link       https://listingslab.com/work/push2talk/
 * @since      1.0.0
 *
 * @package    push2talk
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
