<?php
function push2talk_admin(){
	// json
	
    echo '<h1>Push2talk Plugin > Reach out with accuracy</h1>';
    echo '<p>To add the Push2Talk button to your site, you simply add the widget to a theme area in <a href="' . admin_url() . '/widgets.php">Widgets</a></p>';

    echo '<h2>Example JSON</h2>';

	echo '<div class="json">';
    $example_form = file_get_contents(plugin_dir_path( __FILE__ ) . 'exampleForm.js');
    echo '<pre>';
    print_r($example_form);
    echo '</pre>';
    echo '</div>';


}